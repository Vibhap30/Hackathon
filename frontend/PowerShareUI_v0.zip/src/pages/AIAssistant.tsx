import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  BoltIcon, 
  ChartBarIcon, 
  CpuChipIcon,
  ClockIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  ArrowPathIcon,
  SunIcon,
  BanknotesIcon,
  UserGroupIcon,
  LightBulbIcon
} from '@heroicons/react/24/outline'
import apiService from '../services/api'

interface ActionItem {
  id: string
  title: string
  description: string
  priority: 'high' | 'medium' | 'low'
  timeline: string
  type: string
  data?: any
}

interface OptimizationResult {
  success: boolean
  status: string
  optimization_plan: any
  action_items: ActionItem[]
  estimated_monthly_savings: number
  estimated_carbon_reduction: number
}

const AIAssistant: React.FC = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [optimizationResults, setOptimizationResults] = useState<OptimizationResult | null>(null)
  const [actionItems, setActionItems] = useState<ActionItem[]>([])
  const [aiRecommendations, setAIRecommendations] = useState<any[]>([])
  const [agentsStatus, setAgentsStatus] = useState<any>(null)
  const [analysisProgress, setAnalysisProgress] = useState(0)

  useEffect(() => {
    loadInitialData()
  }, [])

  const loadInitialData = async () => {
    try {
      // Load existing results and recommendations
      const [recommendations, actionItems, optimizationResults, status] = await Promise.all([
        apiService.getAIRecommendations(),
        apiService.getAIActionItems(),
        apiService.getOptimizationResults(),
        apiService.getAIAgentsStatus()
      ])

      setAIRecommendations(recommendations.recommendations || [])
      setActionItems(actionItems.action_items || [])
      setOptimizationResults(optimizationResults.results)
      setAgentsStatus(status)
    } catch (error) {
      console.error('Failed to load AI data:', error)
    }
  }

  const requestEnergyOptimization = async () => {
    setIsAnalyzing(true)
    setAnalysisProgress(0)

    try {
      // Start optimization analysis
      const response = await apiService.requestEnergyOptimization({
        optimization_goals: ['cost_minimization', 'sustainability', 'community_engagement'],
        preferences: {
          risk_tolerance: 'medium',
          sustainability_priority: 'high'
        }
      })

      if (response.success) {
        // Simulate progress
        const progressInterval = setInterval(() => {
          setAnalysisProgress(prev => {
            if (prev >= 90) {
              clearInterval(progressInterval)
              return 90
            }
            return prev + 15
          })
        }, 1000)

        // Poll for results
        setTimeout(async () => {
          clearInterval(progressInterval)
          setAnalysisProgress(100)
          
          // Load results
          const results = await apiService.getOptimizationResults()
          const newActionItems = await apiService.getAIActionItems()
          
          setOptimizationResults(results.results)
          setActionItems(newActionItems.action_items || [])
          setIsAnalyzing(false)
        }, 8000)
      }
    } catch (error) {
      console.error('Failed to request optimization:', error)
      setIsAnalyzing(false)
    }
  }

  const requestTradingAnalysis = async () => {
    try {
      const response = await apiService.requestEnergyTradingAnalysis({
        energy_amount: 10.5,
        max_price: 0.25,
        urgency: 'normal'
      })

      if (response.success) {
        // Refresh recommendations after analysis
        setTimeout(async () => {
          const recommendations = await apiService.getAIRecommendations()
          setAIRecommendations(recommendations.recommendations || [])
        }, 5000)
      }
    } catch (error) {
      console.error('Failed to request trading analysis:', error)
    }
  }

  const completeActionItem = async (actionId: string) => {
    try {
      await apiService.completeActionItem(actionId)
      setActionItems(prev => prev.filter(item => item.id !== actionId))
    } catch (error) {
      console.error('Failed to complete action item:', error)
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100'
      case 'medium': return 'text-yellow-600 bg-yellow-100'
      case 'low': return 'text-green-600 bg-green-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'trading': return BanknotesIcon
      case 'community': return UserGroupIcon
      case 'optimization': return CpuChipIcon
      case 'analysis': return ChartBarIcon
      default: return LightBulbIcon
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-lg">
              <CpuChipIcon className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">AI Energy Assistant</h1>
              <p className="text-gray-600">Personalized energy optimization and trading recommendations</p>
            </div>
          </div>
          
          {agentsStatus && (
            <div className="flex items-center space-x-4 text-sm">
              <span className={`px-2 py-1 rounded-full ${agentsStatus.agents?.energy_trading?.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                Trading Agent: {agentsStatus.agents?.energy_trading?.status || 'inactive'}
              </span>
              <span className={`px-2 py-1 rounded-full ${agentsStatus.agents?.energy_optimization?.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                Optimization Agent: {agentsStatus.agents?.energy_optimization?.status || 'inactive'}
              </span>
            </div>
          )}
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8"
        >
          <button
            onClick={requestEnergyOptimization}
            disabled={isAnalyzing}
            className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="flex items-center justify-between">
              <div className="text-left">
                <h3 className="text-lg font-semibold mb-2">Full Energy Optimization</h3>
                <p className="text-blue-100 text-sm">Comprehensive analysis with AI recommendations</p>
              </div>
              {isAnalyzing ? (
                <ArrowPathIcon className="h-6 w-6 animate-spin" />
              ) : (
                <CpuChipIcon className="h-6 w-6" />
              )}
            </div>
          </button>

          <button
            onClick={requestTradingAnalysis}
            className="bg-gradient-to-r from-green-500 to-teal-600 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all"
          >
            <div className="flex items-center justify-between">
              <div className="text-left">
                <h3 className="text-lg font-semibold mb-2">Smart Trading Analysis</h3>
                <p className="text-green-100 text-sm">AI-powered market insights and recommendations</p>
              </div>
              <BoltIcon className="h-6 w-6" />
            </div>
          </button>
        </motion.div>

        {/* Analysis Progress */}
        {isAnalyzing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-6 rounded-xl shadow-lg mb-8"
          >
            <div className="flex items-center space-x-4 mb-4">
              <ArrowPathIcon className="h-6 w-6 text-blue-600 animate-spin" />
              <h3 className="text-lg font-semibold text-gray-900">Analyzing Your Energy Profile...</h3>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${analysisProgress}%` }}
              ></div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
              <div className={`flex items-center space-x-2 ${analysisProgress > 20 ? 'text-green-600' : 'text-gray-400'}`}>
                <CheckCircleIcon className="h-4 w-4" />
                <span>Gathering user data</span>
              </div>
              <div className={`flex items-center space-x-2 ${analysisProgress > 50 ? 'text-green-600' : 'text-gray-400'}`}>
                <CheckCircleIcon className="h-4 w-4" />
                <span>Analyzing patterns</span>
              </div>
              <div className={`flex items-center space-x-2 ${analysisProgress > 75 ? 'text-green-600' : 'text-gray-400'}`}>
                <CheckCircleIcon className="h-4 w-4" />
                <span>Market analysis</span>
              </div>
              <div className={`flex items-center space-x-2 ${analysisProgress >= 100 ? 'text-green-600' : 'text-gray-400'}`}>
                <CheckCircleIcon className="h-4 w-4" />
                <span>Generating recommendations</span>
              </div>
            </div>
          </motion.div>
        )}

        {/* Optimization Results */}
        {optimizationResults && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white p-6 rounded-xl shadow-lg mb-8"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Optimization Results</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <BanknotesIcon className="h-5 w-5 text-green-600" />
                  <span className="text-sm font-medium text-green-800">Monthly Savings</span>
                </div>
                <p className="text-2xl font-bold text-green-900">
                  ${optimizationResults.estimated_monthly_savings?.toFixed(2) || '0.00'}
                </p>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <SunIcon className="h-5 w-5 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800">Carbon Reduction</span>
                </div>
                <p className="text-2xl font-bold text-blue-900">
                  {optimizationResults.estimated_carbon_reduction?.toFixed(1) || '0.0'} kg/month
                </p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <LightBulbIcon className="h-5 w-5 text-purple-600" />
                  <span className="text-sm font-medium text-purple-800">Action Items</span>
                </div>
                <p className="text-2xl font-bold text-purple-900">
                  {actionItems.length}
                </p>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">AI Analysis Summary</h4>
              <p className="text-gray-700 text-sm">
                {optimizationResults.optimization_plan?.plan_summary || 'Comprehensive energy optimization plan generated with personalized recommendations.'}
              </p>
            </div>
          </motion.div>
        )}

        {/* Action Items */}
        {actionItems.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-white p-6 rounded-xl shadow-lg mb-8"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-4">AI Recommendations</h3>
            
            <div className="space-y-4">
              {actionItems.map((item, index) => {
                const IconComponent = getTypeIcon(item.type)
                return (
                  <div key={item.id} className="border border-gray-200 p-4 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <div className="bg-blue-100 p-2 rounded-lg">
                          <IconComponent className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-semibold text-gray-900">{item.title}</h4>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(item.priority)}`}>
                              {item.priority}
                            </span>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <div className="flex items-center space-x-1">
                              <ClockIcon className="h-3 w-3" />
                              <span>{item.timeline}</span>
                            </div>
                            <span className="capitalize">{item.type}</span>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => completeActionItem(item.id)}
                        className="bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1 rounded-lg text-sm font-medium transition-colors"
                      >
                        Complete
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          </motion.div>
        )}

        {/* Quick Recommendations */}
        {aiRecommendations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-white p-6 rounded-xl shadow-lg"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Recent AI Insights</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {aiRecommendations.map((recommendation, index) => (
                <div key={index} className="border border-gray-200 p-4 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <BoltIcon className="h-4 w-4 text-blue-600" />
                    <span className="font-medium text-gray-900">Trading Opportunity</span>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{recommendation.reasoning}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Confidence: {Math.round(recommendation.confidence_score * 100)}%</span>
                    <span>{recommendation.timing_recommendation}</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Empty State */}
        {!optimizationResults && actionItems.length === 0 && aiRecommendations.length === 0 && !isAnalyzing && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white p-12 rounded-xl shadow-lg text-center"
          >
            <CpuChipIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Welcome to Your AI Assistant</h3>
            <p className="text-gray-600 mb-6">
              Get started by requesting an energy optimization analysis or trading recommendations from our AI agents.
            </p>
            <div className="space-y-3">
              <p className="text-sm text-gray-500">✨ Personalized energy recommendations</p>
              <p className="text-sm text-gray-500">📊 Market analysis and trading insights</p>
              <p className="text-sm text-gray-500">🌱 Sustainability optimization</p>
              <p className="text-sm text-gray-500">👥 Community recommendations</p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

export default AIAssistant
