import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { motion } from 'framer-motion'

// Components
import Navbar from './components/Navbar'
import Footer from './components/Footer'

// Pages
import HomePage from './pages/HomePage'
import Dashboard from './pages/Dashboard'
import EnergyMarketplace from './pages/EnergyMarketplace'
import Community from './pages/Community'
import Analytics from './pages/Analytics'
import Settings from './pages/Settings'
import AIAssistant from './pages/AIAssistant'

// Services
import { WebSocketProvider } from './services/websocket'

function App() {
  return (
    <WebSocketProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-green-50 flex flex-col">
        <Navbar />
        
        <main className="flex-1">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/marketplace" element={<EnergyMarketplace />} />
              <Route path="/community" element={<Community />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/ai-assistant" element={<AIAssistant />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </motion.div>
        </main>
        
        <Footer />
      </div>
    </WebSocketProvider>
  )
}

export default App
